#include <stdio.h>
struct time  {
    int min;
    int sec;
};
struct runner {
    char firstName[20];
    char lastName[20];
    int iD;
    struct time runningtime ;
    struct time record;
};
int main(){
    int n;
    printf("type the number of participants");
    scanf("%d",&n);
    struct runner participant[n];
    struct runner *participantsPointer = &participant;
    for (int i=0;i<n;i++){
        printf("type the first name of participant no.%d:",i+1);
        scanf("%s",(participantsPointer+i)->firstName);

        printf("type the last name of participant np.%d:",i+1);
        scanf("%s",(participantsPointer+i)->lastName);
        
        printf("type the ID of the participant no.%d:",i+1);
        scanf("%d",&(participantsPointer+i)->iD);

        printf("type the current min of running time of participant no.%d:",i+1);
        scanf("%d",&(participantsPointer+i)->runningtime.min);

        printf("type the current sec of running time of participant no.%d:",i+1);
        scanf("%d",&(participantsPointer+i)->runningtime.sec);

        printf("type the min of best record of participant no.%d:",i+1);//problem is here.
        scanf("%d",&(participantsPointer+i)->record.min);

        printf("type the sec of best record of participant no.%d:",i+1);
        scanf("%d",&(participantsPointer+i)->record.sec);
    }
    
    for (int j=0;j<n;j++){
        int t=0;
        int t2=0;
        for (int k=0;k<n;k++){
            
            if (((participantsPointer+j)->runningtime.min)<((participantsPointer+k)->runningtime.min)&& ((participantsPointer+j)->runningtime.sec)<((participantsPointer+k)->runningtime.sec)){
                t++;
            }
        }
        if (t==n-1){
            printf("%s %s",(participantsPointer+j)->firstName,(participantsPointer+j)->lastName);
            if ((participantsPointer+j)->runningtime.min<(participantsPointer+j)->record.min && (participantsPointer+j)->runningtime.sec<(participantsPointer+j)->record.sec){
                printf("the winner has beaten her/his own record");
            }
            else {
                printf("the winner has not beaten her/his own record");
            }
            for (int m=0;m<n;m++){
                if(((participantsPointer+j)->record.min)<((participantsPointer+m)->record.min)&& ((participantsPointer+j)->record.sec)<((participantsPointer+m)->record.sec))
                    t2++;
            }
            if (t2==n-1){
                printf("the winner has beaten  everyones record");
            }
            else 
                printf("the winner has not beaten everyones record");
        }
    }
    return 0;
}