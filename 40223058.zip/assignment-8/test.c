#include <stdio.h>
struct time  {
    int min;
    int sec;
};
struct runner {
    char firstName[20];
    char lastName[20];
    int iD;
    struct time runningtime ;
    struct time *record;
};
int main(){





}